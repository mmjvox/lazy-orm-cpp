#include "MariadbFilteringLazy.h"

namespace LazyOrm {
MariadbFilteringLazy::MariadbFilteringLazy()
{

}

void MariadbFilteringLazy::setLimitConditions(const std::initializer_list<FilterVariant> &filtersList)
{
    std::vector<DbVariant> filters;
    for(const auto& filter : filtersList)
    {
        DbVariant dt = std::visit([=](auto&& arg) -> DbVariant {
                using T = std::decay_t<decltype(arg)>;
                if constexpr (std::is_same_v<T, DbVariant>) {
                    return arg;
                }
                else {return {};}
            }, filter);

        filters.push_back(dt);
    }
    if(filters.size()==2)
    {
        mLimitConditions=filters;
    }
    else if(filters.size()==1)
    {
        mLimitConditions=filters[0];
    }
}

void MariadbFilteringLazy::setOrderConditions(const std::initializer_list<FilterVariant> &filtersList)
{
    std::vector<DbVariant> filters;
    for(const auto& filter : filtersList)
    {
        DbVariant dt = std::visit([=](auto&& arg) -> DbVariant {
                using T = std::decay_t<decltype(arg)>;
                if constexpr (std::is_same_v<T, DbVariant>) {
                    return arg;
                }
                else {return {};}
            }, filter);

        filters.push_back(dt);
    }
    mOrderConditions=filters;
}

void MariadbFilteringLazy::setGroupConditions(const std::initializer_list<FilterVariant> &filtersList)
{
    std::vector<DbVariant> filters;
    for(const auto& filter : filtersList)
    {
        DbVariant dt = std::visit([=](auto&& arg) -> DbVariant {
                using T = std::decay_t<decltype(arg)>;
                if constexpr (std::is_same_v<T, DbVariant>) {
                    return arg;
                }
                else {return {};}
            }, filter);

        filters.push_back(dt);
    }
    mGroupConditions=filters;
}

std::string MariadbFilteringLazy::orderbyString() const
{
    if(mOrderConditions.empty())
    {
        return {};
    }

    std::string retStr(" ORDER BY ");

    std::visit([&retStr, this](auto&& arg) {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, std::vector<DbVariant>>) {
            retStr.append(string_join(",",arg, QuoteFor::OrderType));
        }
        else if constexpr (std::is_same_v<T, DbVariant>) {
            retStr.append(setBackTickForOrderType(arg));
        }
    }, mOrderConditions);

    retStr.append(" ");

    return retStr;
}

std::string MariadbFilteringLazy::limitString() const
{
    if(mLimitConditions.empty())
    {
        return {};
    }

    std::string retStr(" LIMIT ");

    std::visit([&retStr, this](auto&& arg) {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, std::vector<DbVariant>>) {
            if(arg.size()==2){
                retStr.append(string_join(" OFFSET ",arg, QuoteFor::LimitType));
            }
            else{
                retStr.append(string_join(" ",arg, QuoteFor::LimitType));
            }
        }
        else if constexpr (std::is_same_v<T, DbVariant>) {
            retStr.append(arg.toString());
        }
    }, mLimitConditions);

    retStr.append(" ");

    return retStr;
}

std::string MariadbFilteringLazy::groupString() const
{
    if(mGroupConditions.empty())
    {
        return {};
    }

    std::string retStr(" GROUP BY ");

    std::visit([&retStr, this](auto&& arg) {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, std::vector<DbVariant>>) {
            retStr.append(string_join(",",arg, QuoteFor::GroupType));
        }
        else if constexpr (std::is_same_v<T, DbVariant>) {
            retStr.append(arg.setBackTick());
        }
    }, mGroupConditions);

    retStr.append(" ");

    return retStr;
}

MariadbFilteringLazy::MariadbFilteringLazy(const FilteringAbstractLazy &abstractLaz)
{
    *this = abstractLaz;
}

void MariadbFilteringLazy::operator=(const FilteringAbstractLazy &abstractLaz)
{
    copyStateFrom(abstractLaz);
}

}
