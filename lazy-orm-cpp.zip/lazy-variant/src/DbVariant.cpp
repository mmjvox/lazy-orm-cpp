#include "DbVariant.h"
#include <cfloat>
#include <charconv>
#include <climits>
#include <iostream>
#include <sstream>
#include <cmath>
#include <algorithm>
#include <utility>

LazyOrm::DbListType::DbListType(std::vector<DbVariant> values)
    : mValues(std::move(values))
{
}

size_t LazyOrm::DbListType::size() const
{
    return mValues.size();
}

bool LazyOrm::DbListType::empty() const
{
    return mValues.empty();
}

const LazyOrm::DbVariant &LazyOrm::DbListType::at(size_t index) const
{
    return mValues.at(index);
}

std::vector<LazyOrm::DbVariant>::const_iterator LazyOrm::DbListType::begin() const
{
    return mValues.begin();
}

std::vector<LazyOrm::DbVariant>::const_iterator LazyOrm::DbListType::end() const
{
    return mValues.end();
}

bool LazyOrm::DbListType::operator<(const DbListType &other) const
{
    if (size() != other.size()) {
        return size() < other.size();
    }
    for (size_t i = 0; i < size(); ++i) {
        const auto &lhs = static_cast<const DbVariant::Base &>(at(i));
        const auto &rhs = static_cast<const DbVariant::Base &>(other.at(i));
        if (lhs < rhs) {
            return true;
        }
        if (rhs < lhs) {
            return false;
        }
    }
    return false;
}

bool LazyOrm::DbListType::operator==(const DbListType &other) const
{
    if (size() != other.size()) {
        return false;
    }
    for (size_t i = 0; i < size(); ++i) {
        if (static_cast<const DbVariant::Base &>(at(i)) != static_cast<const DbVariant::Base &>(other.at(i))) {
            return false;
        }
    }
    return true;
}

LazyOrm::DbVariant &LazyOrm::DbVariant::set(DbVariant newVariant)
{
    if(*this!=newVariant){
        *this = newVariant;
    }
    return *this;
}

std::string LazyOrm::DbVariant::toString() const
{
    return std::visit([=, this](auto&& arg) -> std::string {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, std::string>) {
            return arg;
        }
        else if constexpr (std::is_same_v<T, UnsignedIntegerVariant>) {
            return toFixedString(toUnsignedInteger());
        }
        else if constexpr (std::is_same_v<T, SignedIntegerVariant>) {
                return  toFixedString(toSignedInteger());
        }
        else if constexpr (std::is_same_v<T, SignedFloatingPointVariant>) {
                return  toFixedString(toSignedFloatingPoint());
        }
        else if constexpr (std::is_same_v<T, bool>) {
                return arg?"true":"false";
        }
        else if constexpr (std::is_same_v<T, BlobType>) {
            std::string result;
            result.reserve(arg.size());
            for (std::byte b : arg) {
                result.push_back(static_cast<char>(b));
            }
            return result;
        }
        else if constexpr (std::is_same_v<T, DbListType>) {
            std::string result = "[no'](";
            for (size_t i = 0; i < arg.size(); ++i) {
                if (i != 0) {
                    result.append(",");
                }
                result.append(arg.at(i).typeName() == "string" ? arg.at(i).setQuote() : arg.at(i).toString());
            }
            return result.append(")");
        }
        return "";
    }, *this);
}

std::string LazyOrm::DbVariant::typeName() const
{
    return std::visit([=](auto&& arg) -> std::string {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, std::string>) {
            return "string";
        }
        else if constexpr (std::is_same_v<T, BlobType>) {
            return "blob";
        }
        else if constexpr (std::is_same_v<T, UnsignedIntegerVariant>) {
            return "uint";
        }
        else if constexpr (std::is_same_v<T, SignedIntegerVariant>) {
            return  "int";
        }
        else if constexpr (std::is_same_v<T, SignedFloatingPointVariant>) {
            return  "float";
        }
        else if constexpr (std::is_same_v<T, bool>) {
            return "boolean";
        }
        else if constexpr (std::is_same_v<T, DbListType>) {
            return "list";
        }
        return "";
    }, *this);
}

bool LazyOrm::DbVariant::isMonostate()
{
    return std::visit([=](auto&& arg) -> bool {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, std::monostate>) {
            return  true;
        }
        return false;
    }, *this);
}

LazyOrm::UnsignedIntegerVariant LazyOrm::DbVariant::toUnsignedIntegerVariant() const
{
    return std::visit([=](auto&& arg) -> UnsignedIntegerVariant {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, UnsignedIntegerVariant>) {
            return  arg;
        }
        throw "error toUnsignedIntegerVariant";
    }, *this);
}

bool LazyOrm::DbVariant::isUnsignedIntegerVariant() const
{
    return std::visit([=](auto&& arg) -> bool {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, UnsignedIntegerVariant>) {
            return  true;
        }
        return  false;
    }, *this);
}

unsigned long long LazyOrm::DbVariant::toUnsignedInteger() const
{
    return std::visit([=](auto&& arg) -> unsigned long long {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, unsigned long long>) {
            return  static_cast<unsigned long long>(arg);
        }
        if constexpr (std::is_same_v<T, unsigned long>) {
            return  static_cast<unsigned long>(arg);
        }
        if constexpr (std::is_same_v<T, unsigned int>) {
            return  static_cast<unsigned int>(arg);
        }
        if constexpr (std::is_same_v<T, unsigned short>) {
            return  static_cast<unsigned short>(arg);
        }
        return 0;
    }, toUnsignedIntegerVariant());
}

bool LazyOrm::DbVariant::can_UInt_Fit_Int(unsigned long long value) const
{
    if (value <= LLONG_MAX) {
        return true;
    }
    return false;
}

bool LazyOrm::DbVariant::can_UInt_Fit_Float(unsigned long long value) const
{
    if (value <= LDBL_MAX) {
        return true;
    }
    return false;
}

unsigned long long LazyOrm::DbVariant::toULongLong() const
{
    if(isUnsignedIntegerVariant()){
        return toUnsignedInteger();
    }
    if(isSignedFloatingPointVariant()){
        auto value = toSignedFloatingPoint();
        if(can_Float_Fit_UInt(value)){
            return value;
        }
        return 0;
    }
    if(isSignedIntegerVariant()){
        auto value = toSignedInteger();
        if(can_Int_Fit_UInt(value)){
            return value;
        }
        return 0;
    }

    return std::visit([=, this](auto&& arg) -> unsigned long long {
        using T = std::decay_t<decltype(arg)>;

        if constexpr (std::is_same_v<T, std::string>) {
            return safeStringToULL(arg);
        }
        if constexpr (std::is_same_v<T, bool>) {
            return arg?1:0;
        }

        return 0;
    }, *this);

    return 0;
}


LazyOrm::SignedFloatingPointVariant LazyOrm::DbVariant::toSignedFloatingPointVariant() const
{
    return std::visit([=](auto&& arg) -> SignedFloatingPointVariant {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, SignedFloatingPointVariant>) {
            return  arg;
        }
        throw "error toSignedFloatingPointVariant";
    }, *this);
}

bool LazyOrm::DbVariant::isSignedFloatingPointVariant() const
{
    return std::visit([=](auto&& arg) -> bool {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, SignedFloatingPointVariant>) {
            return  true;
        }
        return  false;
    }, *this);
}

long double LazyOrm::DbVariant::toSignedFloatingPoint() const
{
    return std::visit([=](auto&& arg) -> long double {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, long double>) {
            return  static_cast<long double>(arg);
        }
        if constexpr (std::is_same_v<T, double>) {
            return  static_cast<double>(arg);
        }
        if constexpr (std::is_same_v<T, float>) {
            return  static_cast<float>(arg);
        }
        return 0;
    }, toSignedFloatingPointVariant());
}

bool LazyOrm::DbVariant::can_Float_Fit_Int(long double value) const
{
    if (value >= LLONG_MIN && value <= LLONG_MAX) {
        return true;
    }
    return false;
}

bool LazyOrm::DbVariant::can_Float_Fit_UInt(long double value) const
{
    if (value >= 0 && value <= ULLONG_MAX) {
        return true;
    }
    return false;
}

std::string LazyOrm::DbVariant::toFixedString(long double value) const
{
    if(isScientific(value)){
        std::ostringstream oss;
        oss << std::scientific << value;
        return toFixedString(oss.str());
    }
    return toFixedString(std::to_string(value));
}

std::string LazyOrm::DbVariant::toFixedString(const std::string &str) const
{
    if(str.find('.') == std::string::npos){
        return str;
    }
    auto fixingStr = str;
    fixingStr.erase(fixingStr.find_last_not_of('0') + 1, std::string::npos);
    if (fixingStr.back() == '.') {
        fixingStr.pop_back();
    }
    return fixingStr;
}

long long LazyOrm::DbVariant::safeStringToLL(std::string value) const
{
    long long converted;
    try{
        std::istringstream iss(value);
        iss >> converted;
        // Convert the long double back to string
        std::ostringstream oss;
        oss.precision(value.size());  // Set the precision to the size of the original string
        if (isScientific(value)) {
            oss << std::scientific << converted;
        } else {
            oss << std::fixed << converted;
        }
        std::string value2 = oss.str();
        // check after and befor is same
        if(toFixedString(value) == toFixedString(value2)){
            return converted;
        }
    } catch(...){
        return 0;
    }
    return 0;
}

unsigned long long LazyOrm::DbVariant::safeStringToULL(std::string value) const
{
    unsigned long long converted;
    try{
        std::istringstream iss(value);
        iss >> converted;
        // Convert the long double back to string
        std::ostringstream oss;
        oss.precision(value.size());  // Set the precision to the size of the original string
        if (isScientific(value)) {
            oss << std::scientific << converted;
        } else {
            oss << std::fixed << converted;
        }
        std::string value2 = oss.str();
        // check after and befor is same
        if(toFixedString(value) == toFixedString(value2)){
            return converted;
        }
    } catch(...){
        return 0;
    }
    return 0;
}

long double LazyOrm::DbVariant::safeStringToLD(std::string value) const
{
    long double converted;
    try{
        std::istringstream iss(value);
        iss >> converted;
        // Convert the long double back to string
        std::ostringstream oss;
        oss.precision(value.size());  // Set the precision to the size of the original string
        if (isScientific(value)) {
            oss << std::scientific << converted;
        } else {
            oss << std::fixed << converted;
        }
        std::string value2 = oss.str();
        // check after and befor is same
        if(toFixedString(value) == toFixedString(value2)){
            return converted;
        }
    } catch(...){
        return 0;
    }
    return 0;
}

long double LazyOrm::DbVariant::toLongDouble() const
{
    if(isSignedFloatingPointVariant()){
        return toSignedFloatingPoint();
    }
    if(isUnsignedIntegerVariant()){
        auto value = toUnsignedInteger();
        if(can_UInt_Fit_Float(value)){
            return value;
        }
        return 0;
    }
    if(isSignedIntegerVariant()){
        auto value = toSignedInteger();
        if(can_Int_Fit_Float(value)){
            return value;
        }
        return 0;
    }

    return std::visit([=, this](auto&& arg) -> long double {
        using T = std::decay_t<decltype(arg)>;

        if constexpr (std::is_same_v<T, std::string>) {
            return safeStringToLD(arg);
        }
        if constexpr (std::is_same_v<T, bool>) {
            return arg?1:0;
        }

        return 0;
    }, *this);

    return 0;
}


LazyOrm::SignedIntegerVariant LazyOrm::DbVariant::toSignedIntegerVariant() const
{
    return std::visit([=](auto&& arg) -> SignedIntegerVariant {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, SignedIntegerVariant>) {
            return  arg;
        }
        throw "error toSignedIntegerVariant";
    }, *this);
}

bool LazyOrm::DbVariant::isSignedIntegerVariant() const
{
    return std::visit([=](auto&& arg) -> bool {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, SignedIntegerVariant>) {
            return  true;
        }
        return  false;
    }, *this);
}

long long LazyOrm::DbVariant::toSignedInteger() const
{
    return std::visit([=](auto&& arg) -> long long {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, long long>) {
            return  static_cast<long long>(arg);
        }
        if constexpr (std::is_same_v<T, long>) {
            return  static_cast<long>(arg);
        }
        if constexpr (std::is_same_v<T, int>) {
            return  static_cast<int>(arg);
        }
        if constexpr (std::is_same_v<T, short>) {
            return  static_cast<short>(arg);
        }
        return 0;
    }, toSignedIntegerVariant());
}

bool LazyOrm::DbVariant::can_Int_Fit_UInt(long long value) const
{
    if (value >= 0 && (unsigned long long)value <= ULLONG_MAX) {
        return true;
    }
    return false;
}

bool LazyOrm::DbVariant::can_Int_Fit_Float(long long value) const
{
    if (value >= -LDBL_MAX && value <= LDBL_MAX) {
        return true;
    }
    return false;
}

long long LazyOrm::DbVariant::toLongLong() const
{
    if(isSignedIntegerVariant()){
        return toSignedInteger();
    }
    if(isSignedFloatingPointVariant()){
        auto value = toSignedFloatingPoint();
        if(can_Float_Fit_Int(value)){
            return value;
        }
        return 0;
    }
    if(isUnsignedIntegerVariant()){
        auto value = toUnsignedInteger();
        if(can_UInt_Fit_Int(value)){
            return value;
        }
        return 0;
    }

    return std::visit([=, this](auto&& arg) -> long long {
        using T = std::decay_t<decltype(arg)>;

        if constexpr (std::is_same_v<T, std::string>) {
            return safeStringToLL(arg);
        }
        if constexpr (std::is_same_v<T, bool>) {
            return arg?1:0;
        }

        return 0;
    }, *this);

    return 0;
}


bool LazyOrm::DbVariant::toBool() const
{
    return std::visit([=, this](auto&& arg) -> bool {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, bool>) {
            return  arg;
        }
        else if constexpr (std::is_same_v<T, BlobType>) {
            return !arg.empty();
        }
        else if constexpr (std::is_same_v<T, DbListType>) {
            return !arg.empty();
        }
        else if constexpr (std::is_same_v<T, std::string>) {
            return !arg.empty();
        }
        else if constexpr (std::is_same_v<T, SignedFloatingPointVariant>) {
            return  toSignedFloatingPoint()>0;
        }
        else if constexpr (std::is_same_v<T, UnsignedIntegerVariant>) {
            return toUnsignedInteger()>0;
        }
        else if constexpr (std::is_same_v<T, SignedIntegerVariant>) {
            return  toSignedInteger()>0;
        }
        return false;
    }, *this);
}

std::string LazyOrm::DbVariant::toLowerString() const
{
    std::string lower = toString();
    for(auto& ch : lower)
    {
        ch=std::tolower(ch);
    }
    return lower;
}

std::string LazyOrm::DbVariant::toUpperString() const
{
    std::string upper = toString();
    for(auto& ch : upper)
    {
        ch=std::toupper(ch);
    }
    return upper;
}

bool LazyOrm::DbVariant::empty()
{
    return std::visit([=](auto&& arg) -> bool {

        using T = std::decay_t<decltype(arg)>;

        if constexpr (std::is_same_v<T, std::monostate>){
            return true;
        }
        else if constexpr (std::is_same_v<T, std::string>) {
            return arg.empty();
        }
        else if constexpr (std::is_same_v<T, BlobType>) {
            return arg.empty();
        }
        else if constexpr (std::is_same_v<T, DbListType>) {
            return arg.empty();
        }

        return false;

    }, *this);
}

const size_t LazyOrm::DbVariant::length() const
{
    return std::visit([=](auto&& arg) -> size_t {

        using T = std::decay_t<decltype(arg)>;

        if constexpr (std::is_same_v<T, std::monostate>) {
            return 0;
        }
        else if constexpr (std::is_same_v<T, std::string>) {
            return arg.length();
        }
        else if constexpr (std::is_same_v<T, BlobType>) {
            return arg.size();
        }
        else if constexpr (std::is_same_v<T, bool>) {
            return 1;
        }
        else if constexpr (std::is_same_v<T, DbListType>) {
            return arg.size();
        }

        return toString().length();

    }, *this);
}

bool LazyOrm::DbVariant::contains(std::string substr) const
{
    return toString().find(substr) != std::string::npos;
}

bool LazyOrm::DbVariant::startsWith(std::string prefix, bool caseSensitive) const
{
#if __cplusplus >= 202002L
    return caseSensitive? toString().starts_with(prefix) : toLowerString().starts_with(prefix);
#else
    const auto str = caseSensitive? toString() : toLowerString();
    if (prefix.size() > str.size()) {
        return false;
    }
    return str.compare(0, prefix.size(), prefix) == 0;
#endif
}

std::string LazyOrm::DbVariant::trim() const {
    auto str = toString();
    auto left = std::ranges::find_if_not(str, [](unsigned char ch){ return std::isspace(ch); });
    auto right = std::ranges::find_if_not(str.rbegin(), str.rend(), [](unsigned char ch){ return std::isspace(ch); }).base();
    if (left >= right) return "";
    return std::string(left, right);
}

std::string LazyOrm::DbVariant::setQuote() const
{
    std::string strVal = toString();
    if(toLowerString()=="true")
    {
        return strVal;
    }
    if(toLowerString()=="false")
    {
        return strVal;
    }
    if(toLowerString()=="null")
    {
        return "NULL";
    }
    auto substr05=strVal.substr(0,5);
    if(substr05=="[no']" or substr05=="[no`]")
    {
        return strVal.substr(5);
    }
    return "'"+ escapeSingleQuotes(strVal) +"'";
}

std::string LazyOrm::DbVariant::setBackTick() const
{
    std::string strVal = trim();

    if(strVal=="*"){
        return strVal;
    }

    auto substr05=strVal.substr(0,5);
    if(substr05=="[no']" or substr05=="[no`]")
    {
        return strVal.substr(5);
    }
    if(strVal.substr(0,6)=="[func]")
    {
        return strVal.substr(6);
    }
    if(strVal.substr(0,8)=="[update]")
    {
        return "`"+strVal.substr(8)+"`";
    }

    auto asPos = toLowerString().find(" as ");
    if(asPos==std::string::npos){
        asPos = toLowerString().find(" -> ");
    }
    if(asPos!=std::string::npos)
    {
        if(strVal.length()>asPos+4){
            if(strVal.at(asPos+4)=='\''){
                return "`"+strVal.insert(asPos,"`");
            }
            return "`"+strVal.insert(asPos,"`").insert(asPos+5,"'")+"'";
        }
    }

    return "`"+strVal+"`";
}

std::string LazyOrm::DbVariant::setDoubleQuote() const
{
    std::string strVal = trim();

    if(strVal=="*"){
        return strVal;
    }

    auto substr05=strVal.substr(0,5);
    if(substr05=="[no']" or substr05=="[no`]")
    {
        return strVal.substr(5);
    }
    if(strVal.substr(0,6)=="[func]")
    {
        return strVal.substr(6);
    }
    if(strVal.substr(0,8)=="[update]")
    {
        return "\""+strVal.substr(8)+"\"";
    }

    auto asPos = toLowerString().find(" as ");
    if(asPos==std::string::npos){
        asPos = toLowerString().find(" -> ");
    }
    if(asPos!=std::string::npos)
    {
        if(strVal.length()>asPos+4){
            if(strVal.at(asPos+4)=='\''){
                strVal = strVal.replace(asPos+4,1,"\"");
                auto lastQuotePos = strVal.size()-1;
                if(strVal[lastQuotePos]!='\''){
                    lastQuotePos = toLowerString().find("\'");
                }
                strVal = strVal.replace(lastQuotePos,1,"\"");
            }
            if(strVal.at(asPos+4)=='\"'){
                return "\""+strVal.insert(asPos,"\"");
            }
            return "\""+strVal.insert(asPos,"\"").insert(asPos+5,"\"")+"\"";
        }
    }

    return "\""+strVal+"\"";
}

std::string LazyOrm::DbVariant::toCleanString() const
{
    std::string strVal = toString();
    auto substr05=strVal.substr(0,5);
    if(substr05=="[no']" or substr05=="[no`]")
    {
        return strVal.substr(5);
    }
    if(strVal.substr(0,6)=="[func]")
    {
        return strVal.substr(6);
    }
    if(strVal.substr(0,8)=="[update]")
    {
        return strVal.substr(8);
    }
    return strVal;
}

bool LazyOrm::DbVariant::isUpdate() const
{
    return toString().substr(0,8)=="[update]";
}

bool LazyOrm::DbVariant::isNumeric() const
{
    return std::visit([=, this](auto&& arg) -> bool {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, std::string>) {
            double value;
            auto [ptr, ec] = std::from_chars(arg.data(), arg.data() + arg.size(), value);
            return ec == std::errc() && ptr == arg.data() + arg.size();
        }
        else if constexpr (std::is_same_v<T, UnsignedIntegerVariant>) {
            return false;
        }
        else if constexpr (std::is_same_v<T, SignedIntegerVariant>) {
            return false;
        }
        else if constexpr (std::is_same_v<T, SignedFloatingPointVariant>) {
            return false;
        }
        else if constexpr (std::is_same_v<T, bool>) {
            return false;
        }
        return false;
    }, *this);
}

LazyOrm::DbVariant LazyOrm::DbVariant::alterStringToBestMatchType()
{
    std::visit([this](auto&& value) {
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<T, std::string>) {
            try {
                // long double converted = std::stold(value);
                long double converted;
                std::istringstream iss(value);
                iss >> converted;

                // Convert the long double back to string
                std::ostringstream oss;
                oss.precision(value.size());  // Set the precision to the size of the original string
                if (isScientific(value)) {
                    oss << std::scientific << converted;
                } else {
                    oss << std::fixed << converted;
                }

                std::string value2 = oss.str();

                if(toFixedString(value) != toFixedString(value2)){
                    throw "parsing with precision loss";
                }

                *this = converted;
            }
            catch (const std::exception&) {}
            catch (...) {}
        }
    }, *this);

    return *this;
}

LazyOrm::DbVariant LazyOrm::DbVariant::alterStringToNumber()
{
    std::visit([this](auto&& value) {
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<T, std::string>) {
            try {
                long double converted;
                std::istringstream iss(value);
                iss >> converted;
                *this = converted;
            }
            catch (const std::exception&) {}
            catch (...) {}
        }
    }, *this);

    return *this;
}


bool LazyOrm::DbVariant::isScientific(const std::string &value) const
{
    return (value.find('e') != std::string::npos) || (value.find('E') != std::string::npos);
}

bool LazyOrm::DbVariant::isScientific(const double &value) const {
    if(value == 0.0){
        return false;
    }
    return (std::fpclassify(value) == FP_SUBNORMAL) ||
           (std::fabs(value) >= 1e6 || std::fabs(value) <= 1e-6);
}

// TODO: needs more improves
std::string LazyOrm::DbVariant::escapeSingleQuotes(const std::string &in) const{
    // count unescaped quotes using a running backslash count
    std::size_t unescaped_quotes = 0;
    std::size_t bs_run = 0; // number of consecutive '\' immediately before current char
    for (char c : in) {
        if (c == '\\') {
            ++bs_run;
        } else {
            if (c == '\'' && (bs_run % 2 == 0)) {
                ++unescaped_quotes;
            }
            bs_run = 0;
        }
    }

    // Allocate once with exact final size
    std::string out;
    out.resize(in.size() + unescaped_quotes); // each unescaped quote adds one '\'

    // write output
    std::size_t w = 0;
    bs_run = 0;
    for (char c : in) {
        if (c == '\\') {
            out[w++] = c;
            ++bs_run;
        } else if (c == '\'') {
            if (bs_run % 2 == 0) {
                out[w++] = '\\';  // insert escape
            }
            out[w++] = '\'';
            bs_run = 0;
        } else {
            out[w++] = c;
            bs_run = 0;
        }
    }
    return out;
}

const std::map<std::string, LazyOrm::Filters> LazyOrm::DbVariant::getFiltersToStringMap() const
{
    return {
        {"None", None},
        {"ORDERBY", ORDERBY},
        {"ORDERBY_DESC", ORDERBY_DESC},
        {"ORDERBY_ASC", ORDERBY_ASC},
        {"LIMIT", LIMIT},
        {"GROUPBY", GROUPBY}
    };
}

bool LazyOrm::DbVariant::operator==(std::monostate mono)
{
    return isMonostate();
}

bool LazyOrm::DbVariant::operator==(std::string str)
{
    return toString()==str;
}

bool LazyOrm::DbVariant::operator==(unsigned long long ull)
{
    return toUnsignedInteger() == ull;
}

bool LazyOrm::DbVariant::operator==(long long ll)
{
    return toLongLong() == ll;
}

bool LazyOrm::DbVariant::operator==(long double ld)
{
    return toLongDouble() == ld;
}

bool LazyOrm::DbVariant::operator==(bool b)
{
    return toBool() == b;
}

bool LazyOrm::DbVariant::operator==(BlobType b)
{
    return toBlob() == b;
}


const std::string LazyOrm::DbVariant::as(const std::string &columnName, const std::string &asName)
{
    return columnName + " as " + asName;
}

bool LazyOrm::DbVariant::isBlob() const
{
    return std::visit([](auto&& arg) -> bool {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, BlobType>) {
            return true;
        }
        return false;
    }, *this);
}

bool LazyOrm::DbVariant::isList() const
{
    return std::visit([](auto&& arg) -> bool {
        using T = std::decay_t<decltype(arg)>;
        return std::is_same_v<T, DbListType>;
    }, *this);
}

LazyOrm::DbListType LazyOrm::DbVariant::toList() const
{
    return std::visit([](auto&& arg) -> DbListType {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, DbListType>) {
            return arg;
        }
        return {};
    }, *this);
}

LazyOrm::BlobType LazyOrm::DbVariant::toBlob() const
{
    return std::visit([this](auto&& arg) -> BlobType {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, BlobType>) {
            return arg;
        }
        else if constexpr (std::is_same_v<T, std::string>) {
            BlobType blob;
            blob.reserve(arg.size());
            for (char c : arg) {
                blob.push_back(static_cast<ByteType>(c));
            }
            return blob;
        }
        else if constexpr (std::is_same_v<T, bool>) {
            BlobType blob;
            blob.push_back(static_cast<ByteType>(arg ? 1 : 0));
            return blob;
        }
        else {
            std::string str = toString();
            BlobType blob;
            blob.reserve(str.size());
            for (char c : str) {
                blob.push_back(static_cast<ByteType>(c));
            }
            return blob;
        }
    }, *this);
}
